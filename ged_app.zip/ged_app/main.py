import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QFileDialog, QMessageBox
from PyQt5.uic import loadUi
import os
from controllers.document_controller import DocumentController

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        loadUi("ui/main_window.ui", self)
        self.controller = DocumentController()
        self.load_documents()

        self.importButton.clicked.connect(self.import_document)
        self.deleteButton.clicked.connect(self.delete_selected)

    def load_documents(self):
        self.docListWidget.clear()
        for doc in self.controller.get_all_documents():
            self.docListWidget.addItem(f"{doc[0]} - {doc[1]}")

    def import_document(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Importer un document")
        if file_path:
            file_name = os.path.basename(file_path)
            self.controller.add_document(file_name, file_path)
            self.load_documents()

    def delete_selected(self):
        selected_item = self.docListWidget.currentItem()
        if selected_item:
            doc_id = int(selected_item.text().split(" - ")[0])
            self.controller.delete_document(doc_id)
            self.load_documents()
        else:
            QMessageBox.warning(self, "Aucun document sélectionné", "Veuillez sélectionner un document à supprimer.")

app = QApplication(sys.argv)
window = MainWindow()
window.setWindowTitle("GED - Gestion Électronique de Documents")
window.show()
sys.exit(app.exec_())
