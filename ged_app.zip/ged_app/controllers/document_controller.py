import sqlite3
from datetime import datetime

class DocumentController:
    def __init__(self):
        self.conn = sqlite3.connect("db/database.db")
        self.create_table()

    def create_table(self):
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nom TEXT,
                chemin TEXT,
                date_ajout TEXT
            )
        """)
        self.conn.commit()

    def add_document(self, nom, chemin):
        self.conn.execute("INSERT INTO documents (nom, chemin, date_ajout) VALUES (?, ?, ?)",
                          (nom, chemin, datetime.now().isoformat()))
        self.conn.commit()

    def get_all_documents(self):
        return self.conn.execute("SELECT id, nom FROM documents").fetchall()

    def delete_document(self, doc_id):
        self.conn.execute("DELETE FROM documents WHERE id = ?", (doc_id,))
        self.conn.commit()
